<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class paisModel extends Model
{
      protected $table = 'Pais';
      protected $primaryKey ='paisId';
}
