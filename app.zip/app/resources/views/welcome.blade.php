<!DOCTYPE html>
<html>
    <head>
        <title>datos</title>
        <style>
        </style>
    </head>
    <body>
        <div class="container">
           @yield('content')
        </div>
    </body>
</html>
