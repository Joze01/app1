@extends('welcome')



@section('content')
{!!$Ubicaciones!!}


@stop
