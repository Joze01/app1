<!DOCTYPE html>
<html>
<head>
	<title>BIENVENIDO</title>
</head>
<body>
<center>
	 <img src="../imgsApp/Monito.jpg">
</center>
</body>
</html>